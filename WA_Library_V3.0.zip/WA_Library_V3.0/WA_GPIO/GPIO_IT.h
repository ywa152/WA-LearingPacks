#ifndef __GPIO_IT_H
#define __GPIO_IT_H

#include "GPIO.h"
#include "main.h"


//�жϷ�����亯��
void WA_GPIOA_IQRHandler(void);
void WA_GPIOB_IQRHandler(void);

#endif
