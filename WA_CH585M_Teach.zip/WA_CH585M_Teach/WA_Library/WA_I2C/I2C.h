#ifndef __I2C_H
#define __I2C_H

#include "main.h"

typedef struct{
    uint8_t scl;
    uint32_t sclpin;
    uint8_t sda;
    uint32_t sdapin;
}I2C_HandleDef;

extern I2C_HandleDef wai2c0;
extern I2C_HandleDef wai2c1;
extern I2C_HandleDef wai2c2;
extern I2C_HandleDef wai2c3;


//ģ��IIC��ʼ��
void WA_I2C_Init(I2C_HandleDef *wai2c,uint8_t group1,uint32_t gpiopin1,uint8_t group2,uint32_t gpiopin2);
//�����Ӻ�����
void WA_I2C_MspInit(I2C_HandleDef *wai2c);

//7bit��ַ���ֽ�д��*******************************************
int WA_I2C_7bit_Single_Write(uint8_t SlaveAddress, uint8_t REG_data);
//7bit��ַ���ֽڶ�ȡ*****************************************
uint8_t WA_I2C_7bit_Single_Read(uint8_t SlaveAddress);
//7bit��ַ���ֽڶ�ȡ*****************************************
int WA_I2C_7bit_Mult_Read(uint8_t SlaveAddress,uint8_t * ptChar,uint8_t size);
//10bit��ַ���ֽ�д��*******************************************
int WA_I2C_10bit_Single_Write(uint8_t SlaveAddress,uint8_t REG_Address,uint8_t REG_data) ;
//10bit��ַ���ֽڶ�ȡ*****************************************
uint8_t WA_I2C_10bit_Single_Read(uint8_t SlaveAddress,uint8_t REG_Address);
//10bit��ַ���ֽڶ�ȡ*****************************************
int WA_I2C_10bit_Mult_Read(uint8_t SlaveAddress,uint8_t REG_Address,uint8_t * ptChar,uint8_t size);

#endif
