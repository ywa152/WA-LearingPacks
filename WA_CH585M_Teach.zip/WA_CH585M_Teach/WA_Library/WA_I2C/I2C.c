/*
    ����CH585M����Դֻ��һ��Ӳ��I2C������ֻд����I2C��I2C���ж�Ҳ�������ã��Ͳ�д�ˡ�
*/
#include "I2C.h"

I2C_HandleDef wai2c0;
I2C_HandleDef wai2c1;
I2C_HandleDef wai2c2;
I2C_HandleDef wai2c3;

//ģ��IIC��ʼ��
void WA_I2C_Init(I2C_HandleDef *wai2c,uint8_t group1,uint32_t gpiopin1,uint8_t group2,uint32_t gpiopin2)
{
    if(wai2c == &wai2c0)
    {
        wai2c->scl = group1;
        wai2c->sclpin = gpiopin1;
        wai2c->sda = group2;
        wai2c->sdapin = gpiopin2;
    }

    if(wai2c == &wai2c1)
    {
        wai2c->scl = group1;
        wai2c->sclpin = gpiopin1;
        wai2c->sda = group2;
        wai2c->sdapin = gpiopin2;
    }

    if(wai2c == &wai2c2)
    {
        wai2c->scl = group1;
        wai2c->sclpin = gpiopin1;
        wai2c->sda = group2;
        wai2c->sdapin = gpiopin2;
    }

    if(wai2c == &wai2c3)
    {
        wai2c->scl = group1;
        wai2c->sclpin = gpiopin1;
        wai2c->sda = group2;
        wai2c->sdapin = gpiopin2;
    }

    WA_I2C_MspInit(wai2c);     
}

//�����Ӻ�����
void WA_I2C_MspInit(I2C_HandleDef *wai2c)
{
    if(wai2c == &wai2c0)
    {
        if(wai2c->scl == GPIOA)
        {
            GPIOA_ModeCfg(wai2c->sclpin,GPIO_ModeIN_PU);
            GPIOA_SetBits(wai2c->sclpin);
        }
            
        if(wai2c->scl == GPIOB)
        {
            GPIOB_ModeCfg(wai2c->sclpin,GPIO_ModeIN_PU);
            GPIOB_SetBits(wai2c->sclpin);
        }
        if(wai2c->sda == GPIOA)
        {
            GPIOA_ModeCfg(wai2c->sdapin,GPIO_ModeIN_PU);
            GPIOA_SetBits(wai2c->sdapin);
        }
        if(wai2c->sda == GPIOB)
        {
            GPIOB_ModeCfg(wai2c->sdapin,GPIO_ModeIN_PU);
            GPIOB_SetBits(wai2c->sdapin);
        }      
    }
}

void SCL_H(void)
{
    if(wai2c0.scl == GPIOA)
        GPIOA_SetBits(wai2c0.sclpin);
    if(wai2c0.scl == GPIOB)
        GPIOB_SetBits(wai2c0.sclpin);

    if(wai2c1.scl == GPIOA)
        GPIOA_SetBits(wai2c1.sclpin);
    if(wai2c1.scl == GPIOB)
        GPIOB_SetBits(wai2c1.sclpin);

    if(wai2c2.scl == GPIOA)
        GPIOA_SetBits(wai2c2.sclpin);
    if(wai2c2.scl == GPIOB)
        GPIOB_SetBits(wai2c2.sclpin);
    
    if(wai2c3.scl == GPIOA)
        GPIOA_SetBits(wai2c3.sclpin);
    if(wai2c3.scl == GPIOB)
        GPIOB_SetBits(wai2c3.sclpin);
}

void SCL_L(void)
{
    if(wai2c0.scl == GPIOA)
        GPIOA_ResetBits(wai2c0.sclpin);
    if(wai2c0.scl == GPIOB)
        GPIOB_ResetBits(wai2c0.sclpin);

    if(wai2c1.scl == GPIOA)
        GPIOA_SetBits(wai2c1.sclpin);
    if(wai2c1.scl == GPIOB)
        GPIOB_ResetBits(wai2c1.sclpin);

    if(wai2c2.scl == GPIOA)
        GPIOA_ResetBits(wai2c2.sclpin);
    if(wai2c2.scl == GPIOB)
        GPIOB_ResetBits(wai2c2.sclpin);
    
    if(wai2c3.scl == GPIOA)
        GPIOA_ResetBits(wai2c3.sclpin);
    if(wai2c3.scl == GPIOB)
        GPIOB_ResetBits(wai2c3.sclpin);
}

void SDA_H(void)
{
    if(wai2c0.sda == GPIOA)
        GPIOA_SetBits(wai2c0.sdapin);
    if(wai2c0.sda == GPIOB)
        GPIOB_SetBits(wai2c0.sdapin);

    if(wai2c1.sda == GPIOA)
        GPIOA_SetBits(wai2c1.sdapin);
    if(wai2c1.sda == GPIOB)
        GPIOB_SetBits(wai2c1.sdapin);

    if(wai2c2.sda == GPIOA)
        GPIOA_SetBits(wai2c2.sdapin);
    if(wai2c2.sda == GPIOB)
        GPIOB_SetBits(wai2c2.sdapin);

    if(wai2c3.sda == GPIOA)
        GPIOA_SetBits(wai2c3.sdapin);
    if(wai2c3.sda == GPIOB)
        GPIOB_SetBits(wai2c3.sdapin);
}

void SDA_L(void)
{
    if(wai2c0.sda == GPIOA)
        GPIOA_ResetBits(wai2c0.sdapin);
    if(wai2c0.sda == GPIOB)
        GPIOB_ResetBits(wai2c0.sdapin);

    if(wai2c1.sda == GPIOA)
        GPIOA_ResetBits(wai2c1.sdapin);
    if(wai2c1.sda == GPIOB)
        GPIOB_ResetBits(wai2c1.sdapin);

    if(wai2c2.sda == GPIOA)
        GPIOA_ResetBits(wai2c2.sdapin);
    if(wai2c2.sda == GPIOB)
        GPIOB_ResetBits(wai2c2.sdapin);

    if(wai2c3.sda == GPIOA)
        GPIOA_ResetBits(wai2c3.sdapin);
    if(wai2c3.sda == GPIOB)
        GPIOB_ResetBits(wai2c3.sdapin);
}

uint8_t SDA_read(void)
{   
    uint8_t i;
    if(wai2c0.sda == GPIOA)
        i = GPIOA_ReadPortPin(wai2c0.sdapin);
    if(wai2c1.sda == GPIOA)
        i = GPIOA_ReadPortPin(wai2c1.sdapin);
    if(wai2c2.sda == GPIOA)
        i = GPIOA_ReadPortPin(wai2c2.sdapin);
    if(wai2c3.sda == GPIOA)
        i = GPIOA_ReadPortPin(wai2c3.sdapin);

    if(wai2c0.sda == GPIOB)
        i = GPIOB_ReadPortPin(wai2c0.sdapin);
    if(wai2c1.sda == GPIOB)
        i = GPIOB_ReadPortPin(wai2c1.sdapin);
    if(wai2c2.sda == GPIOB)
        i = GPIOB_ReadPortPin(wai2c2.sdapin);
    if(wai2c3.sda == GPIOB)
        i = GPIOB_ReadPortPin(wai2c3.sdapin); 

    return i;  
}

void I2C_delay(void)
{
   mDelayuS(100);
}

int I2C_Start(void)
{
    SDA_H();       
    SCL_H();
    I2C_delay();
    if(!SDA_read())return 0;    //SDA��Ϊ�͵�ƽ������æ,�˳�
    SDA_L();
    I2C_delay();
    if(SDA_read()) return 0;    //SDA��Ϊ�ߵ�ƽ�����߳���,�˳�
    SDA_L();
    I2C_delay();
    return 1;    
}

void I2C_Stop(void)
{
    SCL_L();
    I2C_delay();
    SDA_L();
    SDA_H();        
    I2C_delay();
    SCL_H();
    I2C_delay();
    SDA_H();
    I2C_delay();
} 

void I2C_Ack(void)
{    
    SCL_L();
    I2C_delay();
    SDA_L();
    SDA_H();        
    I2C_delay();
    SCL_H();
    I2C_delay();
    I2C_delay();
    SCL_L();
    I2C_delay();
}   

void I2C_NoAck(void)
{    
    SCL_L();
    I2C_delay();
    SDA_H();
    SDA_H();        
    I2C_delay();
    SCL_H();
    I2C_delay();
    SCL_L();
    I2C_delay();
} 

int I2C_WaitAck(void)      //����Ϊ:=1��ACK,=0��ACK
{
    SCL_L();
    I2C_delay();
    I2C_delay();
    SDA_H();
    SCL_H();        
    I2C_delay();
    I2C_delay();
    if(SDA_read())
    {
        SCL_L();
        return 0;
    }
    SCL_L();
    return 1;
}

void I2C_SendByte(uint8_t SendByte) //���ݴӸ�λ����λ//
{
    uint8_t i=8;
    SDA_H();        
    while(i--)
    {
        SCL_L();
        I2C_delay();
        if(SendByte&0x80)
            SDA_H();  
        else 
            SDA_L();   
        SendByte<<=1;
        I2C_delay();
        SCL_H();
        I2C_delay();
        I2C_delay();
    }
    SCL_L();
}  

uint8_t I2C_ReadByte(void)  //���ݴӸ�λ����λ//
{ 
    uint8_t i=8;
    uint8_t ReceiveByte=0;

    SDA_H();                
    SDA_H();        
    while(i--)
    {
        ReceiveByte<<=1;      
        SCL_L();
        I2C_delay();
        I2C_delay();
        SCL_H();
        SDA_H();        
        I2C_delay();    
        I2C_delay();
        if(SDA_read())
        {
            ReceiveByte|=0x01;
        }
    }
    SCL_L();
    return ReceiveByte;
} 

//7bit��ַ���ֽ�д��*******************************************
int WA_I2C_7bit_Single_Write(uint8_t SlaveAddress, uint8_t REG_data)        
{
    if(!I2C_Start())return 0;
    I2C_SendByte(SlaveAddress);   //�����豸��ַ+д�ź�//I2C_SendByte(((REG_Address & 0x0700) >>7) | SlaveAddress & 0xFFFE);//���ø���ʼ��ַ+������ַ 
    if(!I2C_WaitAck()){I2C_Stop(); return 0;}
    I2C_SendByte(REG_data);
    I2C_WaitAck();   
    I2C_Stop(); 
    return 1;
}

//7bit��ַ���ֽڶ�ȡ*****************************************
uint8_t WA_I2C_7bit_Single_Read(uint8_t SlaveAddress)
{   
    unsigned char REG_data;         
    if(!I2C_Start())return 0;
    I2C_SendByte(SlaveAddress); //I2C_SendByte(((REG_Address & 0x0700) >>7) | REG_Address & 0xFFFE);//���ø���ʼ��ַ+������ַ 
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return 0;
    }
    I2C_Start();
    I2C_SendByte(SlaveAddress+1);
    I2C_WaitAck();

    REG_data= I2C_ReadByte();
    I2C_NoAck();
    I2C_Stop();
    //return TRUE;
    return REG_data;

}    

//7bit��ַ���ֽڶ�ȡ*****************************************
int WA_I2C_7bit_Mult_Read(uint8_t SlaveAddress,uint8_t * ptChar,uint8_t size)
{
    uint8_t i;
    
    if(size < 1)
        return 0;
    if(!I2C_Start())
        return 0;
    I2C_SendByte(SlaveAddress);
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return 0;
    }
    I2C_Start();
    I2C_SendByte(SlaveAddress+1);
    I2C_WaitAck();
    
    for(i=1;i<size; i++)
    {
        *ptChar++ = I2C_ReadByte();
        I2C_Ack();
    }
    *ptChar++ = I2C_ReadByte();
    I2C_NoAck();
    I2C_Stop();
    return 1;    
}    



//10bit��ַ���ֽ�д��*******************************************
int WA_I2C_10bit_Single_Write(uint8_t SlaveAddress,uint8_t REG_Address,uint8_t REG_data)        
{
    if(!I2C_Start())return 0;
    I2C_SendByte(SlaveAddress);   //�����豸��ַ+д�ź�//I2C_SendByte(((REG_Address & 0x0700) >>7) | SlaveAddress & 0xFFFE);//���ø���ʼ��ַ+������ַ 
    if(!I2C_WaitAck()){I2C_Stop(); return 0;}
    I2C_SendByte(REG_Address );   //���õ���ʼ��ַ      
    I2C_WaitAck();    
    I2C_SendByte(REG_data);
    I2C_WaitAck();   
    I2C_Stop(); 
    return 1;
}

//10bit��ַ���ֽڶ�ȡ*****************************************
uint8_t WA_I2C_10bit_Single_Read(uint8_t SlaveAddress,uint8_t REG_Address)
{   
    unsigned char REG_data;         
    if(!I2C_Start())return 0;
    I2C_SendByte(SlaveAddress); //I2C_SendByte(((REG_Address & 0x0700) >>7) | REG_Address & 0xFFFE);//���ø���ʼ��ַ+������ַ 
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return 0;
    }
    I2C_SendByte((uint8_t) REG_Address);   //���õ���ʼ��ַ      
    I2C_WaitAck();
    I2C_Start();
    I2C_SendByte(SlaveAddress+1);
    I2C_WaitAck();

    REG_data= I2C_ReadByte();
    I2C_NoAck();
    I2C_Stop();
    //return TRUE;
    return REG_data;

}    

//10bit��ַ���ֽڶ�ȡ*****************************************
int WA_I2C_10bit_Mult_Read(uint8_t SlaveAddress,uint8_t REG_Address,uint8_t * ptChar,uint8_t size)
{
    uint8_t i;
    
    if(size < 1)
        return 0;
    if(!I2C_Start())
        return 0;
    I2C_SendByte(SlaveAddress);
    if(!I2C_WaitAck())
    {
        I2C_Stop();
        return 0;
    }
    I2C_SendByte(REG_Address);    
    I2C_WaitAck();
    
    I2C_Start();
    I2C_SendByte(SlaveAddress+1);
    I2C_WaitAck();
    
    for(i=1;i<size; i++)
    {
        *ptChar++ = I2C_ReadByte();
        I2C_Ack();
    }
    *ptChar++ = I2C_ReadByte();
    I2C_NoAck();
    I2C_Stop();
    return 1;    
}
