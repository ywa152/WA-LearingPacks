/**********************************����WA���ʹ�ý̳�*******************************
 * File Name          : Main.c
 * Author             : ITKeiller
 * Version            : V1.0
 * Date               : 2025/05/01
 * Description        : WA���ѧ
 *********************************************************************************
 δ���������У���ֹ���á�
 *******************************************************************************/

#include "CH58x_common.h"
#include "main.h"
/*********************************************************************
 * @fn      main
 *
 * @brief   ������
 *
 * @return  none
 */
int main()
{
    uint8_t len;

    HSECFG_Capacitance(HSECap_18p);
    SetSysClock(CLK_SOURCE_HSE_PLL_62_4MHz);
    //�����ж�Uart1
    WA_UART_IT_Init(&wauart0,115200);
    //����LED0
    WA_LED_GPIO_Init(&waLED0);
    //PB1�ⲿ�ж�
    WA_GPIO_IT_Init(&waGPIOB,GPIO_Pin_1,GPIO_ITMode_FallEdge);
    //I2C��ʼ������
    WA_I2C_Init(&wai2c0,GPIOB,GPIO_Pin_5,GPIOB,GPIO_Pin_7);
    
    while(1)
    {

    }

}


void WA_UART_TxCallback(Uart_HandleDef *wauart)
{
    if(wauart == &wauart1)
    {

       
    }
}


void WA_GPIOB_EventCallBack(uint32_t gpiopin)
{
    /*�û��Զ�������*/
    /* ��ʼ */
    if(gpiopin == GPIO_Pin_1)
    {
        GPIOA_InverseBits(GPIO_Pin_0);
        WA_printf("%d\r\n",GPIOB_ReadITFlagBit(GPIO_Pin_1));
    }
       

    /* ���� */
}